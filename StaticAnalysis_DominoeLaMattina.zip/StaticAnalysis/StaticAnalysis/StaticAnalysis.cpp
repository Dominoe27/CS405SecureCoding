﻿// QuestionableCode.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <iostream>
#include <numeric>
#include <set>
#include <vector>
#include <memory>   // for smart pointers in the pointer fix

// TODO: You are going to compare the warnings & errors between Visual Studio and CppCheck.
//  Make sure you are using CppCheck 2.1 or greater
//
//  1. Create a Visual Studio Console project with this file as the only file
//  2. Compile it and check the warning and errors
//  3. Create a CppCheck project to analyze a Visual Studio project with this file.
//  4. In CppCheck Edit / Preferences / General Tab: Set Display error id in column "Id", Enable inline suppressions, and Check for inconclusive errors also
//  5. In CppCheck View, Select Check All to ensure all types of checks are enabled
//  6. In CppCheck Analyze, set the C++ Standard to C++17, and Enforce C++
//  7. Make sure to run the analysis
//  8. Save the results to a file (XML format)
//  9. Take a screen shot of the Visual Studio Error list (all errors, warnings, and messages)
//  10. Identify all messages from CppCheck NOT identified in Visual Studio.
//      For each message not in both:
//        Identify the risk as: RISK or NOT RISK
//        Identify which system (Visual Studio or CppCheck) found the issue
//        Provide a couple of sentences describing the issue found

class C
{
    std::set<int> typedefs;
    bool is_type(int type) const
    {
        // original called itself with the same arg, infinite recursion.
        // if the value exists in the set, then it’s that type.
        return typedefs.find(type) != typedefs.end();
    }
};

class A
{
    int x;
    // if this class shouldn’t be copyable.
    A(const A& other) = delete;
};

class MySpecialType
{
public:
    int MyVal = 1;

    void DontThrow() noexcept
    {
        // throwing inside noexcept std::terminate(). 
       
    }
};

// safer pointer contract: take a unique_ptr<int>& so ownership is explicit and no dangling local-address nonsense.
void foo(std::unique_ptr<int>& a)
{
    // original returned address of a local int dangling pointer.
    a = std::make_unique<int>(1);
}

void work_with_arrays(int count)
{
    int buf[10];
    // guard the index 
    if (count >= 0 && count < static_cast<int>(std::size(buf)))
        buf[count] = 0;
    else
        ; // out of range skip.
}

void do_something_useless()
{
    int sum = 0;
    for (auto i = 0; i < 1000; ++i)
    {
        sum += i;
    }

    std::cout << "I summed up " << sum << " as the answer." << std::endl;
}

void vector_test()
{
    std::vector<int> items;
    items.push_back(1);
    items.push_back(2);
    items.push_back(3);

    // erasing while iterating invalidated the iterator.
    // use the erase-while-iterating pattern that returns the next valid iterator.
    for (auto it = items.begin(); it != items.end(); )
    {
        if (*it == 2)
            it = items.erase(it);
        else
            ++it;
    }

    // or: items.erase(std::remove(items.begin(), items.end(), 2), items.end());
}

int a; 

// function says it returns bool, so return a bool. stop returning an int.
bool my_function()
{
    a = 1 + 2;
    return (a == 3);
}

struct Token
{
    Token* next() { return nullptr; }
};

int foo(Token* tok)
{
    // original had `while (tok);` (empty loop) then deref’d tok → either infinite loop or crash.
    while (tok)
    {
        tok = tok->next();
    }
    return 0;
}

int main()
{
    std::vector<int> counts{ 1, 2, 3, 5 };
    int x = 0;
    int y = 0;
    int z = 0;

    std::cout << "Welcome to the Questionable Code Test!" << std::endl;

    //do_something_useless(); 

    work_with_arrays(10); // index 10 is OOB; guarded now so it does nothing

    // use comparison in assert.
    assert(z == 2); // will fail in Debug (as intended), no-op in Release

    assert(my_function() == true);

    try
    {
        int x = 5;
        int y = 5;
        int z = 5;
        std::cout << "x + y + z = " << (x + y + z) << std::endl;
    }
    catch (...)
    {
        
    }

    // use smart pointer so we don’t leak or dangle.
    std::unique_ptr<int> c;
    foo(c);
    // if we wanted to see it do something:
    if (c) std::cout << "c points to: " << *c << std::endl;

    vector_test();

    MySpecialType myobject;
    std::cout << "myobject.MyVal = " << myobject.MyVal << std::endl;

    return 0; // explicit is nice
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
