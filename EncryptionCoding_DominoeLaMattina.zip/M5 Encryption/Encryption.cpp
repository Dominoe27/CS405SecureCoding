// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
static std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // XOR each byte with a rolling key index (accounts for key length)
    const size_t key_length = key.length();
    const size_t source_length = source.length();

    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source; // same size as input
    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = static_cast<char>(source[i] ^ key[i % key_length]);
    }
    return output;
}

/// <summary>
/// read the entire file contents into a string (binary-safe)
/// </summary>
/// <param name="file_name">file name to read</param>
/// <returns>file contents as a string</returns>
static std::string read_file(const std::string& file_name)
{
    // use binary mode and stream buffer to load the whole file
    std::ifstream in(file_name, std::ios::binary);
    if (!in) {
        throw std::runtime_error("Failed to open file for read: " + file_name);
    }
    std::ostringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

/// <summary>
/// get the student name from the provided string data (first line)
/// </summary>
/// <param name="string_data">string data that was saved in the data file</param>
/// <returns>student name extracted from the data</returns>
static std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
        // trim trailing CR if present (Windows files)
        if (!student_name.empty() && student_name.back() == '\r') {
            student_name.pop_back();
        }
    }

    return student_name;
}

/// <summary>
/// save data to a file in the required format
/// </summary>
/// <param name="filename">file name to save</param>
/// <param name="student_name">student name to place in the first line of the file</param>
/// <param name="key">key used to encrypt/decrypt to place in the third line of the file</param>
/// <param name="data">data to write after the header</param>
static void save_data_file(const std::string& filename, const std::string& student_name,
                           const std::string& key, const std::string& data)
{
    // DONE: write header (name, yyyy-mm-dd, key) then raw data bytes in binary mode
    std::ofstream out(filename, std::ios::binary | std::ios::trunc);
    if (!out) {
        throw std::runtime_error("Failed to open file for write: " + filename);
    }

    // timestamp (yyyy-mm-dd)
    std::time_t t = std::time(nullptr);
    std::tm tm{};
#if defined(_WIN32)
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    char date_buf[16]{};
    std::strftime(date_buf, sizeof(date_buf), "%Y-%m-%d", &tm);

    // header
    out << student_name << "\n";
    out << date_buf << "\n";
    out << key << "\n";

    // payload (encrypted or plaintext, exactly as provided)
    out.write(data.data(), static_cast<std::streamsize>(data.size()));
    out.flush();
    if (!out) {
        throw std::runtime_error("Failed to write entire file: " + filename);
    }
}

int main()
{
    try
    {
        // IMPORTANT: keep the filenames as defined in the starter (note the typo on decrypted!)
        const std::string key = "password";
        const std::string file_name = "inputdatafile.txt";
        const std::string encrypted_file_name = "encrypteddatafile.txt";
        const std::string decrypted_file_name = "decrytpteddatafile.txt"; // keep starter typo

        std::cout << "CS 405 - Module 5 XOR Encryption Demo\n";
        std::cout << "Key: '" << key << "' (len=" << key.size() << ")\n\n";

        // read the entire text file into a string
        const std::string file_text = read_file(file_name);

        // get the student name from the first line of the file 
        const std::string student_name = get_student_name(file_text);

        // encrypt plaintext with key
        const std::string encrypted_string = encrypt_decrypt(file_text, key);

        // save encrypted_string to file
        save_data_file(encrypted_file_name, student_name, key, encrypted_string);

        // decrypt encryptedString with key
        const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

        // save decrypted_string to file
        save_data_file(decrypted_file_name, student_name, key, decrypted_string);

        std::cout << "Read File: " << file_name
                  << " - Encrypted To: " << encrypted_file_name
                  << " - Decrypted To: " << decrypted_file_name << std::endl;

        // students submit input file, encrypted file, decrypted file, source code file, and key used

        // quick correctness check for console 
        if (decrypted_string == file_text) {
            std::cout << "[OK] Decrypted output matches original (" << file_text.size() << " bytes)\n";
        } else {
            std::cerr << "[FAIL] Decrypted output differs from original\n";
            return 1;
        }

        return 0;
    }
    catch (const std::exception& ex)
    {
        std::cerr << "[Error] " << ex.what() << "\n";
        return 2;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
