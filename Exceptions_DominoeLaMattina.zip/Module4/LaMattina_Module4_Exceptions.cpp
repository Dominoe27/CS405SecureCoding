// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <string>

// DEMO toggle: set to 1 to show catch-all handler 
#define DEMO_CATCH_ALL 0

#if DEMO_CATCH_ALL
// throw a non-std exception so it bypasses typed handlers and lands in catch(...).
static void trigger_catch_all_demo() {
    std::cout << "About to throw a non-std exception to hit catch-all...\n";
    throw 42; // not derived from std::exception, routes to catch(...)
}
#endif

// Custom exception type derived from std::exception (via runtime_error for what()).
class MyCustomException : public std::runtime_error {
public:
    explicit MyCustomException(const std::string& msg)
        : std::runtime_error(msg) {}
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    // clean and direct: show failure path with context
    // note: we throw before the print below, so those lines would be unreachable
    throw std::runtime_error("Something failed inside do_even_more_custom_application_logic().");

    std::cout << "Running Even More Custom Application Logic." << std::endl; // unreachable in this path
    return true;
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex) {
        // keep it user-facing and helpful; surface what()
        std::cerr << "[std::exception caught in do_custom_application_logic] "
                  << ex.what() << std::endl;
        // continue processing; we don't crash here
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    // using our business-rule style custom exception to exercise ordered catches in main
    throw MyCustomException("Custom application logic hit a business rule violation.");

    std::cout << "Leaving Custom Application Logic." << std::endl; // unreachable after throw
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0.0f) {
        throw std::domain_error("Attempted division by zero.");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    float numerator = 10.0f;
    float denominator = 0.0f;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::domain_error& ex) {
        // only the divide-by-zero case; stays tight to the requirement
        std::cerr << "[Division error] " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.

    try {
        do_division(); // handled locally; we just continue here

#if DEMO_CATCH_ALL
        // this intentionally triggers catch(...) in main
        trigger_catch_all_demo();
#endif

        do_custom_application_logic(); // will throw MyCustomException for main to catch
    }
    catch (const MyCustomException& ex) {
        std::cerr << "[Custom exception caught in main] " << ex.what() << std::endl;
    }
    catch (const std::exception& ex) {
        std::cerr << "[std::exception caught in main] " << ex.what() << std::endl;
    }
    catch (...) {
        std::cerr << "[Unknown exception caught in main] Program terminated safely." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu