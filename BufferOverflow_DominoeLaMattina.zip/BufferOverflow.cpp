// BufferOverflow.cpp
#include <iomanip>
#include <iostream>
#include <limits>   // for std::numeric_limits

int main() {
  std::cout << "Buffer Overflow Example" << std::endl;

  // account_number stays here, right above input buffer
  const std::string account_number = "CharlieBrown42";
  // buffer for user input, 20 chars max
  char user_input[20]{};

  std::cout << "Enter a value: ";

  // use getline to cap input at 19 chars + null
  std::cin.getline(user_input, sizeof(user_input));

  bool tooLong = false;
  if (std::cin.fail() && !std::cin.eof()) {
    // user typed too much, clear and flush leftovers
    tooLong = true;
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  }

  if (tooLong) {
    std::cout << "[Warning] Input was cut off at 19 chars.\n";
    // return non-zero if you want caller to know
    // return 1;
  }

  // show results, account_number should never change
  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;

  return tooLong ? 1 : 0;
}
